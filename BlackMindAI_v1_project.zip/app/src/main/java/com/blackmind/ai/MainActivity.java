package com.blackmind.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    LinearLayout chat;
    EditText input;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    TextView text(String s, int size) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(Color.WHITE);
        v.setPadding(24,18,24,18);
        return v;
    }

    void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));

        TextView title = text("🖤 BlackMind AI", 22);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setBackgroundColor(Color.BLACK);
        root.addView(title, new LinearLayout.LayoutParams(-1,72));

        ScrollView scroll = new ScrollView(this);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(12,18,12,12);

        TextView welcome = text("سلام! من BlackMind AI هستم.\nنسخهٔ اول برنامه آماده است. 🤖\n\nفعلاً رابط چت ساخته شده و در مرحلهٔ بعد موتور هوش مصنوعی را به آن وصل می‌کنیم.", 17);
        welcome.setBackgroundColor(Color.rgb(38,38,38));
        chat.addView(welcome);

        scroll.addView(chat);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(8,8,8,8);
        input = new EditText(this);
        input.setHint("پیامت را بنویس...");
        input.setHintTextColor(Color.GRAY);
        input.setTextColor(Color.WHITE);
        input.setSingleLine(true);

        Button send = new Button(this);
        send.setText("ارسال");
        send.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if(q.isEmpty()) return;
            TextView msg = text("شما: " + q, 16);
            msg.setBackgroundColor(Color.rgb(48,48,48));
            chat.addView(msg);
            TextView reply = text("BlackMind AI: نسخهٔ هوش مصنوعی هنوز وصل نشده؛ اما رابط برنامه آماده است. 🚀", 16);
            reply.setBackgroundColor(Color.rgb(28,28,28));
            chat.addView(reply);
            input.setText("");
        });

        bar.addView(input, new LinearLayout.LayoutParams(0,60,1));
        bar.addView(send, new LinearLayout.LayoutParams(110,60));
        root.addView(bar);

        setContentView(root);
    }
}
